<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('bower_components/font-awesome/css/font-awesome.min.css')); ?>">ß

</head>

<body>
    <?php
        $total = 0;
    ?>
    <div class="container">
        <h1>Anda Telah Melakukan Pemesanan</h1>
        <table class="table">
            <thead>
                <th>No</th>
                <th>Nama Produk</th>
                <th>Harga Produk</th>
                <th>Jumlah Produk</th>
                <th>Subtotal</th>
            </thead>
            <tbody>
             <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($cart->product->name); ?></td>
                    <td>Rp.<?php echo e(number_format($cart->product->price)); ?>-,</td>
                    <td><?php echo e($cart->product->qty); ?></td>
                    <td>Rp.<?php echo e(number_format($cart->qty * $cart->product->price)); ?>-,</td>
                </tr>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php
                $total += ($cart->qty * $cart->product->price)
             ?>
            </tbody>
        </table>
        <h1>Total Pemesanan : <?php echo e(number_format($cart->qty * $cart->product->price)); ?>-,</h1>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/template/mail.blade.php ENDPATH**/ ?>