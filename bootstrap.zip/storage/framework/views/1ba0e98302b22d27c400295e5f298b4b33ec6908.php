<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/cart.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <!-- success message & Error message -->
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(Session::has('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(Session::get('error')); ?>

            </div>
        <?php endif; ?>
        <?php
            $total = 0;    
        ?>
        
        <div>
            <h3><?php echo e($carts->count()); ?> Item in your cart</h3>
        </div>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cart">
                <div class="row">
                    <div class="col-lg-3">
                        <img class="img-cart" src="<?php echo e(asset('storage/images/product.jpg')); ?>" alt="">
                    </div>
                    <div class="col-lg-9">
                        <div class="top">
                            <p class="item-name"><?php echo e($cart->product->name); ?></p>
                            <div class="top-right">
                                <p class="">Rp. <?php echo e($cart->product->price); ?></p>
                                <select name="qty" class="quantity" data-item="<?php echo e($cart->id); ?>">
                                    <?php for($i = 1; $i <= 10; $i++): ?>
                                        <option value="<?php echo e($i); ?>"<?php echo e($cart->qty == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                                    <?php endfor; ?>
                                </select>
                                <!-- Subtotal -->
                                <p class="total-item">Rp.<?php echo e(number_format($cart->product->price * $cart->qty)); ?></p>
                            </div>
                        </div>
                        <hr class="mt-2 mb-2">
                        <div class="bottom">
                            <div class="row">
                                <p class="col-lg-6 item-desc">
                                    Deskripsi
                                </p>
                                <div class="offset-lg-4">

                                </div>
                                <div class="col-lg-2">
                                    <!-- delete cart -->
                                    <form action="<?php echo e(route('delete', $cart->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin Ingin Hapus Barang ini Dari Keranjang???')">Remove</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                $total += ($cart->product->price * $cart->qty);
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="totalz">
            <h4 class="total-price"><b>Total Price</b> : Rp.<?php echo e(number_format($total)); ?>-,</h4>
        </div>
    </div>

    <form action="/checkout" method="POST" style="margin-left: 700px;">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">Checkout</button>
        <a href="/shop" class="btn btn-success">Cari Barang yang lainnya</a>
    </form>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        (function() {
            const classname = document.querySelectorAll('.quantity');

            Array.from(classname).forEach(function(element) {
                element.addEventListener('change', function() {
                    const id = element.getAttribute('data-item');
                    axios.patch(`/cart/${id}`, {
                            quantity: this.value,
                            id: id
                        })
                        .then(function(response) {
                            //console.log(response);
                            window.location.href = '/cart'
                        })
                        .catch(function(error) {
                            console.log(error);
                        });
                })
            })
        })();
    </script>
    <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ecommerce\resources\views/cart/index.blade.php ENDPATH**/ ?>